/*
Copyright (c) 2026 Yu Zhang.
Organization: State Key Laboratory of Cyberspace Security Defense,Institute of Information Engineering, CAS
              School of Cyber Security, University of Chinese Academy of Sciences  
File Description: Declares the ZEN key-encapsulation mechanism layer for the optimized ZEN-128 instance.
*/
#ifndef SYMMETRIC_H
#define SYMMETRIC_H

#include <stddef.h>
#include <stdint.h>
#include "params.h"

#ifdef __cplusplus
extern "C"
{
#endif

    /// @brief Generate pseudorandom output using SHAKE256 with an appended nonce (byte-aligned lengths)
    /// @param[in] output_len_bits Desired output length in bits
    /// @param[in] msg Base address of input message or seed byte array
    /// @param[in] msg_len_bits Input message length in bits
    /// @param[out] output Base address of output pseudorandom byte array
    /// @param[in] nonce Domain-separation nonce appended to the input message
    /// @return None
    void zen_pseudoXOF(unsigned long long output_len_bits, const unsigned char *msg, unsigned long long msg_len_bits, unsigned char *output, uint8_t nonce);

    /* Four lane-separated streams; outlen must be divisible by four. */
    void zen_prf_x4(uint8_t *out, size_t outlen, const uint8_t *seed, uint8_t nonce);

    /* Byte-length interfaces; output sizes are fixed by params.h. */
    void zen_hash_h(uint8_t *out, const uint8_t *in, size_t inlen);
    void zen_hash_g(uint8_t *out, const uint8_t *in, size_t inlen);
    void zen_hash_j(uint8_t *out, const uint8_t *in, size_t inlen);


#ifdef __cplusplus
}
#endif
#endif