#ifndef RANDOMBYTES_H
#define RANDOMBYTES_H

#include <stddef.h>
#include <stdint.h>

/* Return 0 on success, nonzero on failure; discard output on failure. */
int randombytes(uint8_t *out, size_t outlen);

#endif
