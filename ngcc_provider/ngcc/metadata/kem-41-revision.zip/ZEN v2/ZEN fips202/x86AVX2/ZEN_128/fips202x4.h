#ifndef FIPS202X4_H
#define FIPS202X4_H
#ifndef __ASSEMBLER__
#include <stdint.h>
#include <immintrin.h>
/* s points to a 32-byte-aligned internal state of 25 SIMD vectors. */
void f1600x4(__m256i *s, const uint64_t *rc);
#endif
#endif
