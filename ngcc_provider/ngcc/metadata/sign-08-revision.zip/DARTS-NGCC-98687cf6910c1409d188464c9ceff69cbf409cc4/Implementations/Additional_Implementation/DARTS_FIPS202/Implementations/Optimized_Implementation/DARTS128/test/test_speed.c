#include <stdint.h>
#include "../sign.h"
#include "../params.h"
#include "../poly.h"
#include "../polyvec.h"
#include "../polyfix.h"
#include "../polymat.h"
#include "../fft.h"
#include "../ntt.h"
#include "cpucycles.h"
#include "speed_print.h"

#define NTESTS 10000

uint64_t t[NTESTS];

int main(void)
{
	int i;
	size_t smlen;
	uint8_t pk[CRYPTO_PUBLICKEYBYTES];
	uint8_t sk[CRYPTO_SECRETKEYBYTES];
	uint8_t sm[CRYPTO_SIGNATUREBYTES + CRHBYTES];
	uint8_t b;
	uint8_t seedbuf[CRHBYTES], seed[SEEDBYTES];
	polyfixvecl y1;
	polyfixveck y2;
	polyvecl_1 s1;
	polyvecl_1 mat[K];
	polyveck e;
	poly s0;
	poly *a = &s0;
	poly_complex_fp32_16 input;

	// 测试短向量采样性能
	for (i = 0; i < NTESTS; ++i) {
		t[i] = cpucycles();
		polyveckl_ternary_p(&s0, &s1, &e, seedbuf, i);
	}
	print_results("Ternary Sample:", t, NTESTS);

	// 测试随机矩阵生成性能
	for (i = 0; i < NTESTS; ++i) {
		t[i] = cpucycles();
		polymatkl_1_expand(mat, seed);
	}
	print_results("Matrix Expansion:", t, NTESTS);

	// 测试超球采样性能
	for (i = 0; i < NTESTS; ++i) {
		t[i] = cpucycles();
		polyfixveclk_sample_hyperball(&y1, &y2, &b, seedbuf, i);
	}
	print_results("Hyperball Sample y:", t, NTESTS);


	for (i = 0; i < NTESTS; ++i) {
		t[i] = cpucycles();
		polymatkl_1_pointwise_montgomery(&e, mat, &s1);
	}
	print_results("Matrix Pointwise Montgomery:", t, NTESTS);

	// 测试 NTT 性能
	for (i = 0; i < NTESTS; ++i) {
		t[i] = cpucycles();
		poly_ntt(a);
	}
	print_results("NTT:", t, NTESTS);	

	// 测试多项式乘 MONT 性能
	for (i = 0; i < NTESTS; ++i) {
		t[i] = cpucycles();
		poly_mul_mont(a);
	}
	print_results("Multiplication MONT:", t, NTESTS);		

	for (i = 0; i < NTESTS; ++i) {
		t[i] = cpucycles();
		fft_init_and_bitrev(&input, a);   // a 已经是 poly* 类型
		fft(&input);
	}
	print_results("FFT:", t, NTESTS);	

	// 测试计算 N(s) 的性能
	for (i = 0; i < NTESTS; ++i) {
		t[i] = cpucycles();
		polyveckl_sqsing_value(&s0, &s1, &e);
	}
	print_results("N(s):", t, NTESTS);	

	// 测试密钥生成性能
	for(i = 0; i < NTESTS; ++i) {
		t[i] = cpucycles();
		crypto_sign_keypair(pk, sk);
	}
	print_results("Keypair:", t, NTESTS);

	// 测试签名性能
	for(i = 0; i < NTESTS; ++i) {
		t[i] = cpucycles();
		crypto_sign_signature(sm, &smlen, sm, CRHBYTES, sk);
	}
	print_results("Sign:", t, NTESTS);

	// 测试验证性能
	for(i = 0; i < NTESTS; ++i) {
		t[i] = cpucycles();
		crypto_sign_verify(sm, CRYPTO_SIGNATUREBYTES, sm, CRHBYTES, pk);
	}
	print_results("Verify:", t, NTESTS);

	return 0;
	}