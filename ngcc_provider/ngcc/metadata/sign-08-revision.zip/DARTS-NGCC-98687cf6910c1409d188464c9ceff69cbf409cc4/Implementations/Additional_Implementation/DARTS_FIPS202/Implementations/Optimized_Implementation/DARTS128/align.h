#ifndef SIGN_ALIGN_H
#define SIGN_ALIGN_H

#include <stdint.h>
#include <immintrin.h>


#define ALIGNED_UINT8(N)        \
    union {                     \
        uint8_t coeffs[N];      \
        __m256i vec[(N+31)/32]; \
    }

#define ALIGNED_INT32(N)        \
    union {                     \
        int32_t coeffs[N];      \
        __m256i vec[(N+7)/8];   \
    }

#define ALIGNED_INT64(N)        \
    union {                     \
        int64_t coeffs[N];      \
        __m256i vec[(N+3)/4];   \
    }
#endif