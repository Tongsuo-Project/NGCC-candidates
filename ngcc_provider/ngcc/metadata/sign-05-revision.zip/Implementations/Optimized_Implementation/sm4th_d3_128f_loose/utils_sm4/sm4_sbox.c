/*
* SM4 S-box implementations
* We offer two versions, one is lookup table from standard GB/T 32907-2016, 
* and the other is bitwise computation by inversion + affine transform from ACISP 2007.
*/

#include "sm4.h"
#include "../macros.h"

#include <stdint.h>

/* Use secret-indexed SM4 tables only in explicit legacy mode. */
#if REF_USE_LOOKUP_TABLES

/* ================================================================== *
 *  SM4 S-box table (byte substitution, τ)                            *
 * ================================================================== */

static const uint8_t SM4_S[256] = {
    0xD6, 0x90, 0xE9, 0xFE, 0xCC, 0xE1, 0x3D, 0xB7, 0x16, 0xB6, 0x14, 0xC2,
    0x28, 0xFB, 0x2C, 0x05, 0x2B, 0x67, 0x9A, 0x76, 0x2A, 0xBE, 0x04, 0xC3,
    0xAA, 0x44, 0x13, 0x26, 0x49, 0x86, 0x06, 0x99, 0x9C, 0x42, 0x50, 0xF4,
    0x91, 0xEF, 0x98, 0x7A, 0x33, 0x54, 0x0B, 0x43, 0xED, 0xCF, 0xAC, 0x62,
    0xE4, 0xB3, 0x1C, 0xA9, 0xC9, 0x08, 0xE8, 0x95, 0x80, 0xDF, 0x94, 0xFA,
    0x75, 0x8F, 0x3F, 0xA6, 0x47, 0x07, 0xA7, 0xFC, 0xF3, 0x73, 0x17, 0xBA,
    0x83, 0x59, 0x3C, 0x19, 0xE6, 0x85, 0x4F, 0xA8, 0x68, 0x6B, 0x81, 0xB2,
    0x71, 0x64, 0xDA, 0x8B, 0xF8, 0xEB, 0x0F, 0x4B, 0x70, 0x56, 0x9D, 0x35,
    0x1E, 0x24, 0x0E, 0x5E, 0x63, 0x58, 0xD1, 0xA2, 0x25, 0x22, 0x7C, 0x3B,
    0x01, 0x21, 0x78, 0x87, 0xD4, 0x00, 0x46, 0x57, 0x9F, 0xD3, 0x27, 0x52,
    0x4C, 0x36, 0x02, 0xE7, 0xA0, 0xC4, 0xC8, 0x9E, 0xEA, 0xBF, 0x8A, 0xD2,
    0x40, 0xC7, 0x38, 0xB5, 0xA3, 0xF7, 0xF2, 0xCE, 0xF9, 0x61, 0x15, 0xA1,
    0xE0, 0xAE, 0x5D, 0xA4, 0x9B, 0x34, 0x1A, 0x55, 0xAD, 0x93, 0x32, 0x30,
    0xF5, 0x8C, 0xB1, 0xE3, 0x1D, 0xF6, 0xE2, 0x2E, 0x82, 0x66, 0xCA, 0x60,
    0xC0, 0x29, 0x23, 0xAB, 0x0D, 0x53, 0x4E, 0x6F, 0xD5, 0xDB, 0x37, 0x45,
    0xDE, 0xFD, 0x8E, 0x2F, 0x03, 0xFF, 0x6A, 0x72, 0x6D, 0x6C, 0x5B, 0x51,
    0x8D, 0x1B, 0xAF, 0x92, 0xBB, 0xDD, 0xBC, 0x7F, 0x11, 0xD9, 0x5C, 0x41,
    0x1F, 0x10, 0x5A, 0xD8, 0x0A, 0xC1, 0x31, 0x88, 0xA5, 0xCD, 0x7B, 0xBD,
    0x2D, 0x74, 0xD0, 0x12, 0xB8, 0xE5, 0xB4, 0xB0, 0x89, 0x69, 0x97, 0x4A,
    0x0C, 0x96, 0x77, 0x7E, 0x65, 0xB9, 0xF1, 0x09, 0xC5, 0x6E, 0xC6, 0x84,
    0x18, 0xF0, 0x7D, 0xEC, 0x3A, 0xDC, 0x4D, 0x20, 0x79, 0xEE, 0x5F, 0x3E,
    0xD7, 0xCB, 0x39, 0x48
};

uint8_t sm4_compute_sbox(uint8_t in)
{
    return SM4_S[in];
}

#else  /* !REF_USE_LOOKUP_TABLES */

/*
 * Pull in the field library and bit utilities.
 *   bf8_inv_sm4  — multiplicative inverse in GF(2^8) w/ SM4 modulus
 *   parity8      — XOR of all 8 bits of a byte
 *   set_bit      — place bit b at position pos in a byte
 */
#include "fields.h"
#include "utils.h"

/*
 * SM4 affine transform:  y = A·x + c  (over GF(2))
 *
 * Equation: S(x) = A·inverse(A·x + c) + c
 * A ∈ F_2^{8×8},  c ∈ F_2^8
 *
 * The bit-level implementation computes row-wise:
 * Output bit i is computed as the inner product of A's row i with x.
 *
 *   y[i] = <A[i], x>  ⊕  c[i]
 *        = parity8(x & row_mask[i])  ^  c[i]
 *
 * where row_mask[i] encodes ROW i of A.
 * parity8(v) computes v[0]⊕v[1]⊕…⊕v[7], realizing the GF(2) inner product.
 *
 * Row mask encoding: bit j of row_mask[i] == A[i][j]  (bit 0 = LSB).
 * Row masks derived from the SM4 specification (GB/T 32907-2016):
 *
 *   Output  Row i of A (LSB-first display)  row_mask[i]
 *   bit i   A[i][0] ... A[i][7]             (hex)
 *   ------  ------------------------------  -----------
 *     0     1 1 1 0 0 1 0 1                  0xA7
 *     1     1 1 1 1 0 0 1 0                  0x4F
 *     2     0 1 1 1 1 0 0 1                  0x9E
 *     3     1 0 1 1 1 1 0 0                  0x3D
 *     4     0 1 0 1 1 1 1 0                  0x7A
 *     5     0 0 1 0 1 1 1 1                  0xF4
 *     6     1 0 0 1 0 1 1 1                  0xE9
 *     7     1 1 0 0 1 0 1 1                  0xD3
 *
 * Constant c = (c[0]..c[7]) = (1,1,0,0,1,0,1,1).
 * Packed as a byte with c[j] at bit j, this is 0xD3 (LSB-first bit order).
 *
 * Bit-order note:
 *   - When we print a row as "11010011", that is MSB-first display.
 *   - When we store the same row as row_mask[i] = 0xD3, bit 0 is the LSB.
 *
 * Note the MSB-first or LSB-first display
 *
 *  Example for x = 0x01 = 10000000 (LSB-first bit order)
 *   A·x + c = 11010011 (LSB-first) + 11001011 = 00011000 (LSB-first) = 0x18
 *   inv(0x18) = 0xEF = 11110111 (LSB-first)
 *   A·11110111 + c = 11000010 + 11001011 = 00001001 (LSB-first) = 0x90
 *  
 * NOTE: the reason why we use LSB x  is that we implement bf8_inv_sm4 in LSB-first bit order, so the input and output of the S-box are in LSB-first bit order.
 */
static uint8_t sm4_affine(uint8_t x)
{
    return sm4_affine_byte(x);
}

/*
 * Algebraic SM4 S-box:  S(x) = affine( bf8_inv_sm4( affine(x) ) )
 *
 * According to GB/T 32907-2016, the S-box combines:
 * 1. Affine transformation in GF(2): y = A·x + c
 * 2. Multiplicative inverse in GF(2^8) with irreducible polynomial
 *    f(t) = t^8 + t^7 + t^6 + t^5 + t^4 + t^2 + 1 (hex: 0xF5)
 * 3. Another affine transformation (same A and c as step 1)
 *
 * bf8_inv_sm4() is provided by fields.c.
 * bf8_inv_sm4(0) == 0 by convention (matches the S-box table).
 */
/* One unchanged no-table body; ISA selection belongs to key expansion. */
static inline __attribute__((always_inline)) uint8_t sm4_compute_sbox_body(uint8_t in)
{
    return sm4_affine(bf8_inv_sm4(sm4_affine(in)));
}

uint8_t sm4_compute_sbox(uint8_t in)
{
    return sm4_compute_sbox_body(in);
}

#if (defined(__x86_64__) || defined(__i386__)) && (defined(__GNUC__) || defined(__clang__))
__attribute__((target("avx2,avx512f,avx512vl,avx512bw"), flatten))
uint8_t sm4_compute_sbox_avx512(uint8_t in)
{
    return sm4_compute_sbox_body(in);
}
#endif

#endif /* REF_USE_LOOKUP_TABLES */
