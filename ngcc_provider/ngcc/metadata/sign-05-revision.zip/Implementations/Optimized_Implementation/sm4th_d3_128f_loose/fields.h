/* Unused signature-independent helpers were removed; active backend entrypoints remain. */
/*
 * This file implements basic finite field operations for various fields used in SM4th.
 */

#ifndef FIELDS_H
#define FIELDS_H

#include "macros.h"
/* Optional field kernels never set the translation unit ISA. */
#if defined(__x86_64__) && \
    (defined(__GNUC__) || defined(__clang__)) && defined(SM4TH_FIELD_PCLMUL)
#define SM4TH_COMPILE_PCLMUL 1
#define SM4TH_TARGET_PCLMUL __attribute__((target("pclmul,ssse3,sse4.1")))
#else
#define SM4TH_COMPILE_PCLMUL 0
#define SM4TH_TARGET_PCLMUL
#endif

#include "endian_compat.h"
#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#if SM4TH_COMPILE_PCLMUL
#include <immintrin.h>
#endif

typedef uint8_t bf8_t;
typedef uint64_t bf64_t;

#define BF_VALUE(v, i) ((v).values[i])

typedef struct {
  uint64_t values[2];
} bf128_t;

#define BF128C(x0, x1)                                                                             \
  {                                                                                                \
    { x0, x1 }                                                                                     \
  }

#define BF128_ALIGN 8

#define BF128_NUM_BYTES (128 / 8)

// SM4 instance uses SM4 GF(2^8) routines below.

// GF(2^64) implementation

inline bf64_t bf64_load(const uint8_t* src) {
  bf64_t ret;
  memcpy(&ret, src, sizeof(ret));
  return ret;
}

static inline bf64_t bf64_zero(void) {
  return 0;
}

static inline bf64_t bf64_one(void) {
  return 1;
}

static inline bf64_t bf64_add(bf64_t lhs, bf64_t rhs) {
  return lhs ^ rhs;
}

bf64_t bf64_mul(bf64_t lhs, bf64_t rhs);

// GF(2^128) implementation

static inline bf128_t bf128_load(const uint8_t* src) {
  bf128_t ret;
  memcpy(&ret, src, BF128_NUM_BYTES);
  return ret;
}

static inline void bf128_store(uint8_t* dst, bf128_t src) {
  memcpy(dst, &src, BF128_NUM_BYTES);
}

static inline bf128_t bf128_from_bf8(bf8_t src) {
  bf128_t ret      = BF128C(0, 0);
  BF_VALUE(ret, 0) = src;
  return ret;
}

static inline bf128_t bf128_from_bit(uint8_t bit) {
  return bf128_from_bf8(bit & 1);
}

static inline bf128_t bf128_zero(void) {
  const bf128_t ret = BF128C(0, 0);
  return ret;
}

static inline bf128_t bf128_one(void) {
  const bf128_t ret = BF128C(1, 0);
  return ret;
}

static inline bf128_t bf128_add(bf128_t lhs, bf128_t rhs) {
  for (unsigned int i = 0; i != ARRAY_SIZE(lhs.values); ++i) {
    lhs.values[i] ^= rhs.values[i];
  }
  return lhs;
}

bf128_t bf128_mul(bf128_t lhs, bf128_t rhs);
bf128_t bf128_mul_64(bf128_t lhs, bf64_t rhs);
bf128_t bf128_mul_bit(bf128_t lhs, uint8_t rhs);
bf128_t bf128_sum_poly(const bf128_t* xs);
bf128_t bf128_sum_poly_bits(const uint8_t* xs);

/* ================================================================ */
/*  SM4-specific field operations                                    */
/*  GF(2^8) with SM4 polynomial: x^8 + x^7 + x^6 + x^5 + x^4 + x^2 + 1 */
/* ================================================================ */

uint8_t bits_sq_sm4(uint8_t x);
bf8_t bf8_mul_sm4(bf8_t lhs, bf8_t rhs);
bf8_t bf8_square_sm4(bf8_t lhs);
bf8_t bf8_inv_sm4(bf8_t lhs);

bf128_t bf128_byte_combine_sm4(const bf128_t *x);
bf128_t bf128_byte_combine_bits_sm4(uint8_t x);
void bf128_sq_bit_sm4(bf128_t *out_tag, const bf128_t *in_tag);
void bf128_sq_bit_inplace_sm4(bf128_t *tag);
bf128_t bf128_byte_combine_sq_sm4(const bf128_t *x);
bf128_t bf128_byte_combine_bits_sq_sm4(uint8_t x);

/* Unused field-only pseudo-random helpers were removed. */

#endif
