/*
Part of the codes are adapted from the sm4th implementation at https://sm4th.info/,
which uses SPDX-License-Identifier: MIT.
*/

#include "sm4th_d3_128s_loose.h"
#include "sm4.h"
#include "compat.h"
#include "sig_impl.h"
#include "params.h"
#include "owf.h"
#include "utils.h"

#include <assert.h>
#include <stdlib.h>
#include <string.h>

static int sm4th_opt_require_x86(void) {
#if defined(__x86_64__) || defined(__i386__)
  return 0;
#else
  /* Allow non-x86 when acceleration is disabled (portable fallback mode). */
#if defined(SM4TH_ENABLE_SM4_ACCE) && (SM4TH_ENABLE_SM4_ACCE == 1)
  return -1;
#else
  return 0;
#endif
#endif
}

// memory layout of the public key: OWF input || OWF output
// split into two parts
#define PK_INPUT(pk) (pk)
#define PK_OUTPUT(pk) (&pk[16])

// memory layout of the extended secret key: OWF input || OWF key
// &sk[16] is the 128-bit SM4 key
// sk[0..15] is the OWF input, which the signer should also know
#define SK_INPUT(sk) (sk)
#define SK_KEY(sk) (&sk[16])

int sm4th_d3_128s_loose_keygen(uint8_t* pk, uint8_t* sk, const uint8_t* sk_key, const uint8_t* sk_input) {
  /* Validate raw KeyGen buffers before reading or writing them. */
  if (!pk || !sk || !sk_key || !sk_input) {
    return -1;
  }
  /* Explicit-key generation uses the same secret-key restriction. */
  if ((ptr_get_bit(sk_key, 0) & ptr_get_bit(sk_key, 1)) != 0) {
    return 1;
  }

  if (sm4th_opt_require_x86() != 0) {
    return -1;
  }

  memcpy(SK_KEY(sk), sk_key, 128 / 8);
  memcpy(SK_INPUT(sk), sk_input, 16);

  // compute OWF output as PK_OUTPUT, using
  sm4th_d3_128s_loose_owf(SK_KEY(sk), SK_INPUT(sk), PK_OUTPUT(pk));
  // copy OWF input to public key
  memcpy(PK_INPUT(pk), SK_INPUT(sk), 16);

  // declassify public key
  return 0;
}

// given sk, generate extended witness and store owf_key and owf_input into unpacked_sk
int sm4th_d3_128s_loose_unpack_private_key(sm4th_d3_128s_loose_unpacked_private_key_t* unpacked_sk, const uint8_t* sk) {
  if (sm4th_opt_require_x86() != 0) {
    return -1;
  }
  if (!unpacked_sk || !sk) {
    return -1;
  }
  /* Reject an imported secret outside the proved keyspace. */
  if ((ptr_get_bit(SK_KEY(sk), 0) & ptr_get_bit(SK_KEY(sk), 1)) != 0) {
    return 1;
  }

  // copy OWF input and key to unpacked_sk
  memcpy(unpacked_sk->owf_input, SK_INPUT(sk), sizeof(unpacked_sk->owf_input));
  memcpy(unpacked_sk->owf_key, SK_KEY(sk), sizeof(unpacked_sk->owf_key));

  sm4th_d3_128s_loose_owf(SK_KEY(sk), SK_INPUT(sk), unpacked_sk->owf_output);
  // declassify OWF output

  // generate extended witness using sk: owf_key, owf_input
  const params_t* params = sm4th_params_d3_s();
  const unsigned int witness_bytes = params->ell / 8;
  unpacked_sk->witness = malloc(witness_bytes);
  /* Return safely when witness allocation fails in release builds. */
  if (!unpacked_sk->witness) {
    return -1;
  }
  sm4_extend_witness(params, unpacked_sk->witness, unpacked_sk->owf_key, unpacked_sk->owf_input);

  return 0;
}
  
// check if the keypair is valid
int sm4th_d3_128s_loose_validate_keypair(const uint8_t* pk, const uint8_t* sk) {
  if (sm4th_opt_require_x86() != 0) {
    return -1;
  }
  if (!sk || !pk) {
    return -1;
  }

  if ((ptr_get_bit(SK_KEY(sk), 0) & ptr_get_bit(SK_KEY(sk), 1)) != 0) {
    return 1;
  }

  uint8_t pk_check[32];
  sm4th_d3_128s_loose_owf(SK_KEY(sk), SK_INPUT(sk), PK_OUTPUT(pk_check));
  memcpy(PK_INPUT(pk_check), SK_INPUT(sk), 16);

  return timingsafe_bcmp(pk_check, pk, sizeof(pk_check)) == 0 ? 0 : 2;
}

/* Reject messages above the specification limit before processing them. */
int sm4th_d3_128s_loose_sign_with_randomness(const uint8_t* sk, const uint8_t* message, size_t message_len, const uint8_t* rho, size_t rho_len, uint8_t* signature, size_t* signature_len) {
  if (sm4th_opt_require_x86() != 0) {
    return -1;
  }
  if (!sk || !signature || !signature_len || *signature_len < SM4TH_D3_S_LOOSE_SIGNATURE_SIZE || !rho || rho_len != SIGN_RANDOMNESS_BYTES || (!message && message_len) || message_len > (UINT64_C(1) << 60)) {
    return -1;
  }

  /* Initialize cleanup state before validating an unpacked private key. */
  sm4th_d3_128s_loose_unpacked_private_key_t unpacked_sk = {0};
  int ret = sm4th_d3_128s_loose_unpack_private_key(&unpacked_sk, sk);
  // as long as ret!=0, this would enter into the if branch
  // if ret==0, then continue to sign
  if (ret) {
    sm4th_d3_128s_loose_clear_unpacked_private_key(&unpacked_sk);
    return ret;
  }

  ret = sm4th_d3_128s_loose_unpacked_sign_with_randomness(&unpacked_sk, message, message_len, rho, rho_len, signature, signature_len);
  sm4th_d3_128s_loose_clear_unpacked_private_key(&unpacked_sk);
  return ret;
}

int sm4th_d3_128s_loose_unpacked_sign_with_randomness(const sm4th_d3_128s_loose_unpacked_private_key_t* sk, const uint8_t* message, size_t message_len, const uint8_t* rho, size_t rho_len, uint8_t* signature, size_t* signature_len) {
  if (sm4th_opt_require_x86() != 0) {
    return -1;
  }

  /* Split signing requires an allocated witness and valid rho input. */
  if (!sk || !sk->witness || !rho || rho_len != SIGN_RANDOMNESS_BYTES || !signature || !signature_len || *signature_len < SM4TH_D3_S_LOOSE_SIGNATURE_SIZE || (!message && message_len) || message_len > (UINT64_C(1) << 60)) {
    return -1;
  }
  /* Split signing must also reject forbidden imported secret bits. */
  if ((ptr_get_bit(sk->owf_key, 0) & ptr_get_bit(sk->owf_key, 1)) != 0) {
    return 1;
  }

  const params_t* params = sm4th_params_d3_s();
  /* Propagate counter exhaustion through the public signing API. */
  const int sign_result = sm4th_sign(params, signature, message, message_len, sk->owf_key, sk->owf_input, sk->owf_output,
             sk->witness, rho, rho_len);
  if (sign_result != 0) {
    *signature_len = 0;
    return sign_result;
  }
  *signature_len = SM4TH_D3_S_LOOSE_SIGNATURE_SIZE;

  return 0;
}

int sm4th_d3_128s_loose_verify(const uint8_t* pk, const uint8_t* message, size_t message_len, const uint8_t* signature, size_t signature_len) {
  if (sm4th_opt_require_x86() != 0) {
    return -1;
  }
  if (!pk || !signature || signature_len != SM4TH_D3_S_LOOSE_SIGNATURE_SIZE || (!message && message_len) || message_len > (UINT64_C(1) << 60)) {
    return -1;
  }

  const params_t* params = sm4th_params_d3_s();
  return sm4th_verify(params, message, message_len, signature, PK_INPUT(pk), PK_OUTPUT(pk));
}

void sm4th_d3_128s_loose_clear_private_key(uint8_t* key) {
  explicit_bzero(key, SM4TH_D3_S_LOOSE_PRIVATE_KEY_SIZE);
}

void sm4th_d3_128s_loose_clear_unpacked_private_key(sm4th_d3_128s_loose_unpacked_private_key_t* key) {
  if (!key) return;
  if (key->witness) {
    const params_t* params = sm4th_params_d3_s();
    const unsigned int witness_bytes = params->ell / 8;
    explicit_bzero(key->witness, witness_bytes);
    free(key->witness);
    key->witness = NULL;
  }
  explicit_bzero(key, sizeof(*key));
}
