/* Unused signature-independent helpers were removed; active backend entrypoints remain. */
/*
 * OWF functions (SM4-only for sm4th_d3_128s_tight).
 */

#ifndef OWF_H
#define OWF_H

#include <stdint.h>

void owf_sm4_128(const uint8_t* key, const uint8_t* input, uint8_t* output);

#define sm4th_d3_128s_tight_owf owf_sm4_128

#endif
